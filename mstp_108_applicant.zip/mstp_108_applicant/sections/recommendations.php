<h2 id="chat" class="sectionHead">Recommendations</h2>

<!--RECOMMENDATIONS-->
<ul id="recommends">

	<li><h3>Current Company</h3></li>
	
	<li>
		<div class="details">
			<h3>Tina Smith</h3>
			<h4>Professional Position</h4>
		</div>
		<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque."</p>
	</li>
	<li>
		<div class="details">
			<h3>Uncle Smith</h3>
			<h4>Professional Position</h4>
		</div>
		<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque."</p>
	</li>
	
	<li><h3>Some Other Company</h3></li>
	
	<li>
		<div class="details">
			<h3>Justin Smith</h3>
			<h4>Professional Position</h4>
		</div>
		<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque."</p>
	</li>
	<li>
		<div class="details">
			<h3>Shawn Smith</h3>
			<h4>Professional Position</h4>
		</div>
		<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque."</p>
	</li>
	
	<li><h3>Another Company</h3></li>
	
	<li>
		<div class="details">
			<h3>Matthew Smith</h3>
			<h4>Professional Position</h4>
		</div>
		<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque."</p>
	</li>
	<li>
		<div class="details">
			<h3>Rob Smith</h3>
			<h4>Professional Position</h4>
		</div>
		<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut justo nibh, mattis sit amet consequat a, varius vitae metus. Proin pharetra sodales pellentesque."</p>
	</li>
	
</ul><!--end recommends-->

<div class="clear"></div>