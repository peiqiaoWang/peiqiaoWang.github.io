<h2 id="ribbon" class="sectionHead">Honors &amp; Awards</h2>

<!--HONORS / AWARDS-->
<ul id="honorsAwards">
	<li>Academy Award for Best Sound Design in a Bathroom</li>
	<li>Emmy Award for Most Used Extra in a Drama</li>
	<li>Grammy Award for Best Use of a Goat in a Soundtrack</li>
	<li>S.A.G. Award for Touching the Ground</li>
	<li>Presented with the Honor of Throwing Pies at Donald Trump</li>
	<li>Featured in Dog & Country Monthly (issue 298, pg. 20)</li>
</ul><!--end honorsAwards-->

<div class="clear"></div>